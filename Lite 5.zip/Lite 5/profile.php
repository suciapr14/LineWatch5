<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$currentUser = getCurrentUser();
$profiles = getProfiles();
$videos = getVideos();

$profileUserId = $_GET['user_id'] ?? $currentUser['id'];
$isOwnProfile = ($profileUserId === $currentUser['id']);
$profileUser = getUserById($profileUserId);

if (!$profileUser) {
    header('Location: index.php');
    exit;
}

$profile = $profiles[$profileUserId] ?? [
    'display_name' => $profileUser['username'],
    'avatar' => 'default.png',
    'bio' => ''
];

// Handle video deletion
if (isset($_GET['delete_video']) && $isOwnProfile) {
    $videoId = $_GET['delete_video'];
    if (isset($videos[$videoId])) {
        // Hapus file video dan thumbnail
        @unlink(VIDEO_DIR . $videos[$videoId]['filename']);
        @unlink(THUMBNAIL_DIR . $videos[$videoId]['thumbnail']);

        // Hapus dari array dan simpan
        unset($videos[$videoId]);
        saveVideos($videos);

        header('Location: profile.php');
        exit;
    }
}

// Handle update profile
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isOwnProfile) {
    $displayName = trim($_POST['display_name']);
    $bio = trim($_POST['bio']);

    // Handle avatar upload
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['avatar'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid().'.'.$ext;
        $avatarPath = AVATAR_DIR . $filename;

        if (move_uploaded_file($file['tmp_name'], $avatarPath)) {
            // Hapus avatar lama jika bukan default
            if ($profile['avatar'] !== 'default.png') {
                @unlink(AVATAR_DIR . $profile['avatar']);
            }

            $profile['avatar'] = $filename;
        }
    }

    $profile['display_name'] = $displayName;
    $profile['bio'] = $bio;

    $profiles[$profileUserId] = $profile;
    saveProfiles($profiles);

    header('Location: profile.php');
    exit;
}

// Filter video milik user ini
$userVideos = array_filter($videos, function($video) use ($profileUserId) {
    return $video['user_id'] === $profileUserId;
});

// Urutkan video terbaru duluan
usort($userVideos, function($a, $b) {
    return $b['created_at'] <=> $a['created_at'];
});

// Fungsi untuk mengecek apakah video duplikat
function isDuplicateVideo($video, $seenVideos) {
    foreach ($seenVideos as $seen) {
        if ($video['filename'] === $seen['filename']) {
            return true;
        }
    }
    return false;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - ClipShare</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #FF2D55;
            --secondary: #25F4EE;
            --dark: #121212;
            --light-dark: #1E1E1E;
            --text: #FFFFFF;
            --text-light: rgba(255, 255, 255, 0.7);
            --divider: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: var(--dark);
            color: var(--text);
            height: 100vh;
            overflow: hidden;
        }

        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        .header {
            padding: 0.5rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--dark);
            z-index: 100;
            position: relative;
            border-bottom: 1px solid var(--divider);
        }

        .logo {
            font-weight: 700;
            font-size: 1.2rem;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav {
            display: flex;
            gap: 1.5rem;
        }

        .nav a {
            color: var(--text);
            text-decoration: none;
            font-size: 0.9rem;
        }

        .nav a.active {
            color: var(--primary);
            font-weight: 600;
        }

        .profile-container {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
        }

        .profile-header {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary);
        }

        .profile-info {
            flex: 1;
        }

        .display-name {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .username {
            font-size: 1rem;
            color: var(--text-light);
            margin-bottom: 0.5rem;
        }

        .bio {
            font-size: 0.9rem;
            line-height: 1.5;
            margin-bottom: 1rem;
        }

        .stats {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .stat {
            text-align: center;
        }

        .stat-value {
            font-size: 1.2rem;
            font-weight: 700;
        }

        .stat-label {
            font-size: 0.8rem;
            color: var(--text-light);
        }

        .edit-profile-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            margin-bottom: 1.5rem;
        }

        .edit-profile-btn:hover {
            opacity: 0.9;
        }

        .videos-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--divider);
        }

        .videos-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 0.5rem;
        }

.video-thumbnail {
    width: 100%;
    max-width: 120px; /* Ukuran kecil */
    aspect-ratio: 9/12;
    object-fit: cover;
    border-radius: 5px;
    background: var(--light-dark);
    overflow: hidden;
}

.video-thumbnail img {
    width: 100%;
    height: 80%;
    object-fit: cover;
    border-radius: 5px;
}
        .video-item {
            position: relative;
            margin-bottom: 1rem;
        }

        .video-views {
            position: absolute;
            bottom: 45px;
            left: 5px;
            font-size: 0.8rem;
            background: rgba(0, 0, 0, 0.7);
            padding: 0.2rem 0.4rem;
            border-radius: 3px;
        }

        .video-actions {
            margin-top: 0.5rem;
            text-align: center;
        }

        .delete-video-btn {
            background: #ff3333;
            color: white;
            border: none;
            padding: 0.3rem 0.6rem;
            border-radius: 4px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: background 0.2s;
        }

        .delete-video-btn:hover {
            background: #ff0000;
        }

        .delete-video-btn i {
            margin-right: 0.3rem;
        }

        .edit-profile-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            display: none;
            align-items: center;
            justify-content: center;
        }

        .edit-profile-content {
            background: var(--light-dark);
            padding: 1.5rem;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
        }

        .edit-profile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .edit-profile-title {
            font-size: 1.2rem;
            font-weight: 600;
        }

        .close-edit-profile {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border-radius: 5px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            font-size: 1rem;
        }

        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }

        .avatar-preview {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 1rem;
            display: block;
            border: 3px solid var(--primary);
        }

        .save-btn {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 5px;
            background: var(--primary);
            color: white;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .save-btn:hover {
            opacity: 0.9;
        }

        .follow-btn {
            background: <?= isFollowing($currentUser['id'], $profileUserId) ? '#333' : 'var(--primary)' ?>;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            margin-bottom: 1.5rem;
            transition: background 0.3s;
        }

        .follow-btn:hover {
            background: <?= isFollowing($currentUser['id'], $profileUserId) ? '#444' : '#FF2D66' ?>;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="header">
            <div class="logo">ClipShare</div>
            <nav class="nav">
                <a href="index.php"><i class="fas fa-home"></i> Feed</a>
                <a href="profile.php" class="active"><i class="fas fa-user"></i> Profil</a>
            </nav>
        </header>
        
        <!-- Profile Content -->
        <div class="profile-container">
            <div class="profile-header">
                <img src="<?= AVATAR_DIR . $profile['avatar'] ?>" class="avatar" id="avatar-preview">
                <div class="profile-info">
                    <h1 class="display-name"><?= htmlspecialchars($profile['display_name']) ?></h1>
                    <div class="username">@<?= htmlspecialchars($profileUser['username']) ?></div>
                    <div class="bio"><?= nl2br(htmlspecialchars($profile['bio'])) ?></div>
                </div>
            </div>
            
            <div class="stats">
                <div class="stat">
                    <div class="stat-value"><?= count($userVideos) ?></div>
                    <div class="stat-label">Video</div>
                </div>
                <div class="stat">
                    <div class="stat-value"><?= getFollowerCount($profileUserId) ?></div>
                    <div class="stat-label">Pengikut</div>
                </div>
                <div class="stat">
                    <div class="stat-value"><?= getFollowingCount($profileUserId) ?></div>
                    <div class="stat-label">Mengikuti</div>
                </div>
                <div class="stat">
                    <div class="stat-value">
                        <?= array_reduce($userVideos, function($carry, $video) {
                            return $carry + ($video['views'] ?? 0);
                        }, 0) ?>
                    </div>
                    <div class="stat-label">Views</div>
                </div>
            </div>

            <?php if (!$isOwnProfile): ?>
                <button class="follow-btn" 
                        onclick="window.location.href='?follow=<?= $profileUserId ?>&from=<?= urlencode($_SERVER['REQUEST_URI']) ?>'">
                    <?= isFollowing($currentUser['id'], $profileUserId) ? 'Following' : 'Follow' ?>
                </button>
            <?php endif; ?>
            
            <?php if ($isOwnProfile): ?>
                <button class="edit-profile-btn" id="edit-profile-btn">
                    <i class="fas fa-edit"></i> Edit Profil
                </button>
            <?php endif; ?>
            
            <h2 class="videos-title">Video Saya</h2>
            
            <?php if (empty($userVideos)): ?>
                <p>Tidak ada video yang diupload</p>
            <?php else: ?>
                <div class="videos-grid">
                    <?php 
                    $seenVideos = [];
                    foreach ($userVideos as $videoId => $video): 
                        // Skip video duplikat
                        if (isDuplicateVideo($video, $seenVideos)) {
                            continue;
                        }
                        $seenVideos[] = $video;
                    ?>
                        <div class="video-item">
                            <a href="index.php#video-<?= $videoId ?>">
                                <img src="<?= THUMBNAIL_DIR . $video['thumbnail'] ?>" class="video-thumbnail">
                                <div class="video-views"><?= formatNumber($video['views']) ?> views</div>
                            </a>
                            <?php if ($isOwnProfile): ?>
                                <div class="video-actions">
                                    <button class="delete-video-btn" 
                                            onclick="if(confirm('Yakin ingin menghapus video ini?')) { 
                                                window.location.href='?delete_video=<?= $videoId ?>'
                                            }">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Edit Profile Modal -->
        <?php if ($isOwnProfile): ?>
        <div class="edit-profile-modal" id="edit-profile-modal">
            <div class="edit-profile-content">
                <div class="edit-profile-header">
                    <h2 class="edit-profile-title">Edit Profil</h2>
                    <button class="close-edit-profile" id="close-edit-profile">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <img src="<?= AVATAR_DIR . $profile['avatar'] ?>" class="avatar-preview" id="avatar-edit-preview">
                        <input type="file" id="avatar-upload" name="avatar" accept="image/*">
                    </div>
                    
                    <div class="form-group">
                        <label for="display_name">Nama Tampilan</label>
                        <input type="text" id="display_name" name="display_name" 
                               value="<?= htmlspecialchars($profile['display_name']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="bio">Bio</label>
                        <textarea id="bio" name="bio"><?= htmlspecialchars($profile['bio']) ?></textarea>
                    </div>
                    
                    <button type="submit" class="save-btn">Simpan Perubahan</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
        // Edit profile modal
        <?php if ($isOwnProfile): ?>
        const editProfileBtn = document.getElementById('edit-profile-btn');
        const editProfileModal = document.getElementById('edit-profile-modal');
        const closeEditProfileBtn = document.getElementById('close-edit-profile');
        const avatarUpload = document.getElementById('avatar-upload');
        const avatarPreview = document.getElementById('avatar-preview');
        const avatarEditPreview = document.getElementById('avatar-edit-preview');
        
        editProfileBtn.addEventListener('click', () => {
            editProfileModal.style.display = 'flex';
        });
        
        closeEditProfileBtn.addEventListener('click', () => {
            editProfileModal.style.display = 'none';
        });
        
        editProfileModal.addEventListener('click', (e) => {
            if (e.target === editProfileModal) {
                editProfileModal.style.display = 'none';
            }
        });
        
        avatarUpload.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                const file = e.target.files[0];
                const reader = new FileReader();
                
                reader.onload = function(event) {
                    avatarEditPreview.src = event.target.result;
                    avatarPreview.src = event.target.result;
                };
                
                reader.readAsDataURL(file);
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>