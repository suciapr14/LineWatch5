<?php
require_once 'functions.php';

// Redirect jika belum login
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$currentUser = getCurrentUser();
$videos = getVideos();
$profiles = getProfiles();

// Handle upload video
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['video'])) {
    $file = $_FILES['video'];
    $caption = trim($_POST['caption']);
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid().'.'.$ext;
        $videoPath = VIDEO_DIR . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $videoPath)) {
            // Buat thumbnail
            $thumbnailName = pathinfo($filename, PATHINFO_FILENAME).'.jpg';
            $thumbnailPath = THUMBNAIL_DIR . $thumbnailName;
            generateThumbnail($videoPath, $thumbnailPath);
            
            // Tambahkan video ke database
            $newVideo = [
                'id' => uniqid(),
                'user_id' => $currentUser['id'],
                'filename' => $filename,
                'thumbnail' => $thumbnailName,
                'caption' => $caption ?: 'Video baru saya',
                'created_at' => time(),
                'views' => 0
            ];
            
            $videos[] = $newVideo;
            saveVideos($videos);
            
            // Inisialisasi likes untuk video baru
            $likes = getLikes();
            $likes[$newVideo['id']] = [];
            saveLikes($likes);
            
            header('Location: index.php');
            exit;
        }
    }
}

// Handle like/unlike
if (isset($_GET['like'])) {
    $videoId = $_GET['like'];
    $likeCount = toggleLike($currentUser['id'], $videoId);
    
    // AJAX response
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['count' => $likeCount]);
        exit;
    }
    
    header('Location: index.php');
    exit;
}

// Handle komentar
if (isset($_POST['comment'])) {
    $videoId = $_POST['video_id'];
    $commentText = trim($_POST['comment_text']);
    
    if (!empty($commentText)) {
        addComment($videoId, $currentUser['id'], $commentText);
    }
    
    header("Location: index.php#video-$videoId");
    exit;
}

// Handle follow/unfollow
if (isset($_GET['follow'])) {
    $userIdToFollow = $_GET['follow'];
    toggleFollow($currentUser['id'], $userIdToFollow);
    header("Location: " . ($_GET['from'] ?? 'index.php'));
    exit;
}

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    setcookie('remember_user', '', time() - 3600, '/');
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TikTok Clone</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #FF2D55;
            --secondary: #25F4EE;
            --dark: #121212;
            --light-dark: #1E1E1E;
            --text: #FFFFFF;
            --text-light: rgba(255, 255, 255, 0.7);
            --divider: rgba(255, 255, 255, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: var(--dark);
            color: var(--text);
            height: 100vh;
            overflow: hidden;
        }

        .app-container {
            display: flex;
            flex-direction: column;
            height: 100vh;
        }

        .header {
            padding: 0.5rem 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--dark);
            z-index: 100;
            position: relative;
            border-bottom: 1px solid var(--divider);
        }

        .logo {
            font-weight: 700;
            font-size: 1.2rem;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav {
            display: flex;
            gap: 1.5rem;
        }

        .nav a {
            color: var(--text);
            text-decoration: none;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav a.active {
            color: var(--primary);
            font-weight: 600;
        }

        .main-content {
            flex: 1;
            display: flex;
            overflow: hidden;
        }

        .video-feed {
            flex: 1;
            height: calc(100vh - 50px);
            overflow-y: auto;
            scroll-snap-type: y mandatory;
            scroll-behavior: smooth;
            -webkit-overflow-scrolling: touch;
        }

        .video-container {
            scroll-snap-align: start;
            height: calc(100vh - 50px);
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #000;
            overflow: hidden;
        }

        video {
            max-width: 100%;
            max-height: 100%;
            width: auto;
            height: auto;
            object-fit: contain;
        }

        .video-info {
            position: absolute;
            bottom: 80px;
            left: 16px;
            right: 90px;
            z-index: 10;
            color: var(--text);
            font-size: 14px;
            line-height: 1.5;
            display: flex;
            flex-direction: column;
            gap: 8px;
            max-width: 80%;
        }

        .username {
            font-weight: 700;
            font-size: 16px;
            color: var(--text);
        }

        .caption {
            font-size: 15px;
            color: var(--text-light);
            line-height: 1.6;
        }

        .views {
            font-size: 14px;
            color: var(--text-light);
        }

        .video-actions {
            position: absolute;
            right: 16px;
            bottom: 180px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            z-index: 10;
        }

        .action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            background: none;
            border: none;
            color: white;
            cursor: pointer;
        }

        .action-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 4px;
            background: rgba(22, 24, 35, 0.4);
            backdrop-filter: blur(4px);
            transition: transform 0.2s;
        }

        .action-icon i {
            font-size: 20px;
        }

        .action-count {
            font-size: 12px;
            color: var(--text-light);
        }

        .like-btn .action-icon {
            color: var(--text-light);
        }

        .liked .action-icon {
            color: var(--primary) !important;
        }

        .follow-btn .action-icon {
            color: var(--text-light);
        }

        .following .action-icon {
            color: var(--secondary) !important;
        }

        .pulse {
            animation: pulse 0.5s ease;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        .comments-section {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(22, 24, 35, 0.9);
            backdrop-filter: blur(10px);
            padding: 1rem;
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
            transform: translateY(100%);
            transition: transform 0.3s ease;
            max-height: 60vh;
            overflow-y: auto;
            z-index: 100;
            display: none;
        }

        .comments-section.show {
            display: block;
            transform: translateY(0);
        }

        .comments-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .comments-title {
            font-size: 1.2rem;
            font-weight: 600;
        }

        .close-comments {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .comments-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .comment {
            display: flex;
            gap: 0.8rem;
        }

        .comment-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        .comment-content {
            flex: 1;
        }

        .comment-user {
            font-weight: 700;
            font-size: 14px;
            color: var(--secondary);
        }

        .comment-text {
            font-size: 14px;
            margin: 4px 0;
        }

        .comment-time {
            font-size: 12px;
            color: var(--text-light);
        }

        .comment-form {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid var(--divider);
        }

        .comment-input {
            flex: 1;
            padding: 0.8rem;
            border-radius: 8px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: white;
            font-size: 14px;
        }

        .comment-submit {
            padding: 0 1rem;
            border-radius: 8px;
            border: none;
            background: var(--primary);
            color: white;
            font-weight: 600;
            cursor: pointer;
        }

        .upload-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            z-index: 100;
            box-shadow: 0 4px 12px rgba(255, 45, 85, 0.3);
            cursor: pointer;
        }

        .upload-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            display: none;
            align-items: center;
            justify-content: center;
        }

        .upload-content {
            background: var(--light-dark);
            padding: 1.5rem;
            border-radius: 1rem;
            width: 90%;
            max-width: 400px;
        }

        .upload-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }

        .upload-title {
            font-size: 1.2rem;
            font-weight: 600;
        }

        .close-upload {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .upload-area {
            border: 2px dashed rgba(255, 255, 255, 0.4);
            border-radius: 0.5rem;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            margin-bottom: 1rem;
        }

        .upload-icon {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .file-input {
            display: none;
        }

        .file-label {
            padding: 0.8rem;
            border-radius: 0.5rem;
            background: var(--primary);
            color: white;
            font-weight: 600;
            cursor: pointer;
            text-align: center;
            width: 100%;
            border: none;
        }

        .caption-input {
            width: 100%;
            padding: 0.8rem;
            border-radius: 0.5rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            margin-bottom: 1rem;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="header">
            <div class="logo">ClipShare</div>
            <nav class="nav">
                <a href="index.php" class="active"><i class="fas fa-home"></i> Feed</a>
                <a href="profile.php"><i class="fas fa-user"></i> Profil</a>
                <a href="?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
        </header>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Video Feed -->
            <main class="video-feed" id="video-feed">
                <?php foreach ($videos as $index => $video): 
                    $user = getUserById($video['user_id']);
                    $profile = $profiles[$video['user_id']] ?? ['display_name' => $user['username'], 'avatar' => 'default.png'];
                    $isLiked = isVideoLiked($currentUser['id'], $video['id']);
                    $isFollowing = isFollowing($currentUser['id'], $user['id']);
                    $isOwnProfile = ($user['id'] === $currentUser['id']);
                ?>
                    <div class="video-container" data-video-id="<?= $video['id'] ?>" id="video-<?= $index ?>-container">
                        <!-- Video dengan lazy loading -->
                        <video 
                            id="video-<?= $index ?>" 
                            loop 
                            playsinline 
                            preload="none"
                            poster="<?= THUMBNAIL_DIR . $video['thumbnail'] ?>"
                            data-src="<?= VIDEO_DIR . $video['filename'] ?>"
                        >
                            <!-- Source akan diisi oleh JavaScript -->
                        </video>
                        
                        <!-- Video Info -->
                        <div class="video-info">
                            <div class="username">
                                <a href="profile.php?user_id=<?= $user['id'] ?>" style="color: inherit; text-decoration: none;">
                                    <?= htmlspecialchars($profile['display_name']) ?>
                                </a>
                            </div>
                            <div class="caption"><?= htmlspecialchars($video['caption']) ?></div>
                            <div class="views"><?= formatNumber($video['views']) ?> views</div>
                        </div>
                        
                        <!-- Video Actions -->
                        <div class="video-actions">
                            <button class="action-btn like-btn <?= $isLiked ? 'liked' : '' ?>" 
                                    data-video-id="<?= $video['id'] ?>">
                                <div class="action-icon">
                                    <i class="fas fa-heart"></i>
                                </div>
                                <span class="action-count"><?= formatNumber(getLikeCount($video['id'])) ?></span>
                            </button>
                            
                            <button class="action-btn comment-btn" onclick="toggleCommentSection(<?= $index ?>)">
                                <div class="action-icon">
                                    <i class="fas fa-comment"></i>
                                </div>
                                <span class="action-count"><?= formatNumber(count(getVideoComments($video['id']))) ?></span>
                            </button>
                            
                            <?php if (!$isOwnProfile): ?>
                            <button class="action-btn follow-btn <?= $isFollowing ? 'following' : '' ?>" 
                                    onclick="toggleFollow('<?= $user['id'] ?>', this)">
                                <div class="action-icon">
                                    <i class="fas fa-<?= $isFollowing ? 'user-check' : 'user-plus' ?>"></i>
                                </div>
                                <span class="action-count"><?= $isFollowing ? 'Following' : 'Follow' ?></span>
                            </button>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Comments Section -->
                        <div class="comments-section" id="comments-<?= $index ?>">
                            <div class="comments-header">
                                <h3 class="comments-title">Komentar</h3>
                                <button class="close-comments" onclick="toggleCommentSection(<?= $index ?>)">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            
                            <div class="comments-list">
                                <?php $videoComments = getVideoComments($video['id']); ?>
                                <?php if (!empty($videoComments)): ?>
                                    <?php foreach ($videoComments as $comment): ?>
                                        <div class="comment">
                                            <img src="<?= AVATAR_DIR . ($profiles[$comment['user_id']]['avatar'] ?? 'default.png') ?>" class="comment-avatar">
                                            <div class="comment-content">
                                                <div class="comment-user"><?= htmlspecialchars($comment['display_name']) ?></div>
                                                <div class="comment-text"><?= htmlspecialchars($comment['text']) ?></div>
                                                <div class="comment-time"><?= timeAgo($comment['timestamp']) ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p>Belum ada komentar</p>
                                <?php endif; ?>
                            </div>
                            
                            <form class="comment-form" method="post">
                                <input type="hidden" name="video_id" value="<?= $video['id'] ?>">
                                <input type="text" name="comment_text" class="comment-input" placeholder="Tulis komentar..." required>
                                <button type="submit" name="comment" class="comment-submit">Kirim</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </main>
        </div>
        
        <!-- Upload Button -->
        <button class="upload-btn" id="upload-btn">
            <i class="fas fa-plus"></i>
        </button>
        
        <!-- Upload Modal -->
        <div class="upload-modal" id="upload-modal">
            <div class="upload-content">
                <div class="upload-header">
                    <h2 class="upload-title">Upload Video</h2>
                    <button class="close-upload" id="close-upload">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form method="post" enctype="multipart/form-data">
                    <input type="file" id="video-upload" name="video" accept="video/*" class="file-input" required>
                    <label for="video-upload" class="upload-area">
                        <i class="fas fa-cloud-upload-alt upload-icon"></i>
                        <div>Pilih video untuk diupload</div>
                        <div>MP4 atau WebM, maksimal 50MB</div>
                    </label>
                    
                    <input type="text" name="caption" class="caption-input" placeholder="Tambahkan caption...">
                    
                    <button type="submit" class="file-label">Upload</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Fungsi untuk memuat video secara lazy
        function loadVideo(videoElement) {
            const src = videoElement.getAttribute('data-src');
            if (!src || videoElement.hasAttribute('data-loaded')) return;
            
            videoElement.setAttribute('data-loaded', 'true');
            
            // Buat source element
            const source = document.createElement('source');
            source.src = src;
            source.type = 'video/mp4';
            
            // Kosongkan dan tambahkan source baru
            videoElement.innerHTML = '';
            videoElement.appendChild(source);
            
            // Coba play (dengan mute)
            const playPromise = videoElement.play();
            
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.log('Autoplay prevented:', error);
                });
            }
            
            // Record view
            const videoId = videoElement.closest('.video-container').dataset.videoId;
            fetch(`?view=${videoId}`, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
        }

        // IntersectionObserver untuk lazy load video
        const videoObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const video = entry.target.querySelector('video') || entry.target;
                
                if (entry.isIntersecting) {
                    // Load video jika belum dimuat
                    if (!video.hasAttribute('data-loaded')) {
                        loadVideo(video);
                    }
                    
                    // Coba play video
                    const playPromise = video.play();
                    
                    if (playPromise !== undefined) {
                        playPromise.catch(error => {
                            console.log('Autoplay prevented:', error);
                        });
                    }
                } else {
                    // Pause video jika tidak terlihat
                    video.pause();
                }
            });
        }, {
            threshold: 0.6
        });

        // Observasi semua video container
        document.querySelectorAll('.video-container').forEach(container => {
            videoObserver.observe(container);
            
            // Klik video untuk toggle play/pause
            const video = container.querySelector('video');
            video.addEventListener('click', function(e) {
                if (e.target.closest('.video-actions') || e.target.closest('.comments-section')) return;
                
                if (this.paused) {
                    this.play();
                } else {
                    this.pause();
                }
            });
            
            // Loop video
            video.addEventListener('ended', function() {
                this.currentTime = 0;
                this.play();
            });
        });

        // Handle like dengan AJAX
        document.querySelectorAll('.like-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const videoId = this.getAttribute('data-video-id');
                const icon = this.querySelector('.action-icon');
                const countElement = this.querySelector('.action-count');
                
                fetch(`?like=${videoId}`, {
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    countElement.textContent = formatNumber(data.count);
                    icon.classList.add('pulse');
                    this.classList.toggle('liked');
                    
                    setTimeout(() => {
                        icon.classList.remove('pulse');
                    }, 500);
                });
            });
        });

        // Handle follow dengan AJAX
        function toggleFollow(userId, btn) {
            const icon = btn.querySelector('.action-icon');
            const countElement = btn.querySelector('.action-count');
            
            fetch(`?follow=${userId}&from=index.php`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(() => {
                btn.classList.toggle('following');
                const isFollowing = btn.classList.contains('following');
                
                // Update icon dan text
                icon.innerHTML = `<i class="fas fa-${isFollowing ? 'user-check' : 'user-plus'}"></i>`;
                countElement.textContent = isFollowing ? 'Following' : 'Follow';
                
                // Animasi
                icon.classList.add('pulse');
                setTimeout(() => {
                    icon.classList.remove('pulse');
                }, 500);
            });
        }

        // Toggle comment section
        function toggleCommentSection(index) {
            const section = document.getElementById(`comments-${index}`);
            section.classList.toggle('show');
            
            // Pause/play video saat komentar dibuka/tutup
            const video = document.getElementById(`video-${index}`);
            if (section.classList.contains('show')) {
                video.pause();
            } else {
                video.play();
            }
        }

        // Format angka
        function formatNumber(num) {
            num = parseInt(num) || 0;
            if (num >= 1000000) return (num/1000000).toFixed(1) + 'M';
            if (num >= 1000) return (num/1000).toFixed(1) + 'K';
            return num;
        }

        // Upload modal
        const uploadBtn = document.getElementById('upload-btn');
        const uploadModal = document.getElementById('upload-modal');
        const closeUploadBtn = document.getElementById('close-upload');
        const videoUpload = document.getElementById('video-upload');

        uploadBtn.addEventListener('click', () => {
            uploadModal.style.display = 'flex';
        });

        closeUploadBtn.addEventListener('click', () => {
            uploadModal.style.display = 'none';
        });

        uploadModal.addEventListener('click', (e) => {
            if (e.target === uploadModal) {
                uploadModal.style.display = 'none';
            }
        });

        videoUpload.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                const file = e.target.files[0];
                const uploadArea = document.querySelector('.upload-area');
                uploadArea.innerHTML = `
                    <i class="fas fa-check-circle upload-icon" style="color: #25F4EE"></i>
                    <div>${file.name}</div>
                    <div>${(file.size / 1024 / 1024).toFixed(1)}MB</div>
                `;
            }
        });

        // Blokir klik kanan pada video
        document.addEventListener('contextmenu', function(e) {
            if (e.target.tagName === 'VIDEO') {
                e.preventDefault();
                alert('Download video tidak diizinkan');
            }
        }, false);
    </script>
</body>
</html>