<?php
session_start();

// Konfigurasi direktori
define('DATA_DIR', 'data/');
define('ASSETS_DIR', 'assets/');
define('AVATAR_DIR', ASSETS_DIR . 'avatars/');
define('VIDEO_DIR', ASSETS_DIR . 'videos/');
define('THUMBNAIL_DIR', ASSETS_DIR . 'thumbnails/');

// Buat direktori jika belum ada
if (!file_exists(DATA_DIR)) mkdir(DATA_DIR, 0755, true);
if (!file_exists(AVATAR_DIR)) mkdir(AVATAR_DIR, 0755, true);
if (!file_exists(VIDEO_DIR)) mkdir(VIDEO_DIR, 0755, true);
if (!file_exists(THUMBNAIL_DIR)) mkdir(THUMBNAIL_DIR, 0755, true);

// File JSON
define('USERS_FILE', DATA_DIR . 'users.json');
define('VIDEOS_FILE', DATA_DIR . 'videos.json');
define('PROFILES_FILE', DATA_DIR . 'profiles.json');
define('FOLLOWS_FILE', DATA_DIR . 'follows.json');
define('COMMENTS_FILE', DATA_DIR . 'comments.json');
define('LIKES_FILE', DATA_DIR . 'likes.json');

// Inisialisasi file jika belum ada
if (!file_exists(USERS_FILE)) file_put_contents(USERS_FILE, '[]');
if (!file_exists(VIDEOS_FILE)) file_put_contents(VIDEOS_FILE, '[]');
if (!file_exists(PROFILES_FILE)) file_put_contents(PROFILES_FILE, '{}');
if (!file_exists(FOLLOWS_FILE)) file_put_contents(FOLLOWS_FILE, '{}');
if (!file_exists(COMMENTS_FILE)) file_put_contents(COMMENTS_FILE, '{}');
if (!file_exists(LIKES_FILE)) file_put_contents(LIKES_FILE, '{}');

// Fungsi bantuan database
function getUsers() {
    return json_decode(file_get_contents(USERS_FILE), true);
}

function saveUsers($users) {
    file_put_contents(USERS_FILE, json_encode($users, JSON_PRETTY_PRINT));
}

function getVideos() {
    return json_decode(file_get_contents(VIDEOS_FILE), true);
}

function saveVideos($videos) {
    file_put_contents(VIDEOS_FILE, json_encode($videos, JSON_PRETTY_PRINT));
}

function getProfiles() {
    return json_decode(file_get_contents(PROFILES_FILE), true);
}

function saveProfiles($profiles) {
    file_put_contents(PROFILES_FILE, json_encode($profiles, JSON_PRETTY_PRINT));
}

function getFollows() {
    return json_decode(file_get_contents(FOLLOWS_FILE), true);
}

function saveFollows($follows) {
    file_put_contents(FOLLOWS_FILE, json_encode($follows, JSON_PRETTY_PRINT));
}

function getComments() {
    return json_decode(file_get_contents(COMMENTS_FILE), true);
}

function saveComments($comments) {
    file_put_contents(COMMENTS_FILE, json_encode($comments, JSON_PRETTY_PRINT));
}

function getLikes() {
    return json_decode(file_get_contents(LIKES_FILE), true);
}

function saveLikes($likes) {
    file_put_contents(LIKES_FILE, json_encode($likes, JSON_PRETTY_PRINT));
}

// Fungsi bantuan aplikasi
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['id'] == $_SESSION['user_id']) {
            return $user;
        }
    }
    return null;
}

function getUserById($id) {
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['id'] == $id) {
            return $user;
        }
    }
    return null;
}

function generateThumbnail($videoPath, $thumbnailPath) {
    $im = imagecreatetruecolor(640, 360);
    $bgColor = imagecolorallocate($im, rand(50, 200), rand(50, 200), rand(50, 200));
    imagefill($im, 0, 0, $bgColor);
    imagejpeg($im, $thumbnailPath);
    imagedestroy($im);
    return true;
}

function formatNumber($num) {
    if ($num >= 1000000) return round($num/1000000, 1).'M';
    if ($num >= 1000) return round($num/1000, 1).'K';
    return $num;
}

function timeAgo($timestamp) {
    $diff = time() - $timestamp;
    if ($diff < 60) return 'baru saja';
    if ($diff < 3600) return floor($diff/60).' menit lalu';
    if ($diff < 86400) return floor($diff/3600).' jam lalu';
    return date('d M Y', $timestamp);
}

// Fungsi follow/unfollow
function isFollowing($followerId, $followingId) {
    $follows = getFollows();
    return isset($follows[$followerId]) && in_array($followingId, $follows[$followerId]);
}

function toggleFollow($followerId, $followingId) {
    $follows = getFollows();
    
    if (!isset($follows[$followerId])) {
        $follows[$followerId] = [];
    }
    
    if (in_array($followingId, $follows[$followerId])) {
        $follows[$followerId] = array_diff($follows[$followerId], [$followingId]);
    } else {
        $follows[$followerId][] = $followingId;
    }
    
    saveFollows($follows);
}

function getFollowerCount($userId) {
    $follows = getFollows();
    $count = 0;
    
    foreach ($follows as $followers) {
        if (in_array($userId, $followers)) {
            $count++;
        }
    }
    
    return $count;
}

function getFollowingCount($userId) {
    $follows = getFollows();
    return isset($follows[$userId]) ? count($follows[$userId]) : 0;
}

// Fungsi komentar
function addComment($videoId, $userId, $text) {
    $comments = getComments();
    
    if (!isset($comments[$videoId])) {
        $comments[$videoId] = [];
    }
    
    $user = getUserById($userId);
    $profile = getProfiles()[$userId] ?? ['display_name' => $user['username']];
    
    $comments[$videoId][] = [
        'id' => uniqid(),
        'user_id' => $userId,
        'username' => $user['username'],
        'display_name' => $profile['display_name'],
        'text' => $text,
        'timestamp' => time()
    ];
    
    saveComments($comments);
}

function getVideoComments($videoId) {
    $comments = getComments();
    return $comments[$videoId] ?? [];
}

// Fungsi like/unlike
function isVideoLiked($userId, $videoId) {
    $likes = getLikes();
    return isset($likes[$videoId]) && in_array($userId, $likes[$videoId]);
}

function toggleLike($userId, $videoId) {
    $likes = getLikes();
    
    if (!isset($likes[$videoId])) {
        $likes[$videoId] = [];
    }
    
    if (in_array($userId, $likes[$videoId])) {
        $likes[$videoId] = array_diff($likes[$videoId], [$userId]);
    } else {
        $likes[$videoId][] = $userId;
    }
    
    saveLikes($likes);
    return count($likes[$videoId]);
}

function getLikeCount($videoId) {
    $likes = getLikes();
    return isset($likes[$videoId]) ? count($likes[$videoId]) : 0;
}

// Fungsi view tracking
function recordView($videoId, $userId = null) {
    $videos = getVideos();
    
    foreach ($videos as &$video) {
        if ($video['id'] === $videoId) {
            $video['views'] = ($video['views'] ?? 0) + 1;
            break;
        }
    }
    
    saveVideos($videos);
}
?>