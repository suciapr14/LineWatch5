<?php
session_start();

if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    setcookie('remember_user', '', time() - 3600, '/');
    header('Location: login.php');
    exit;
}

require_once 'functions.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $action = $_POST['action'];

    $users = getUsers();

    if ($action === 'register') {
        if (empty($username) || empty($password)) {
            $error = 'Username dan password harus diisi';
        } else {
            $userExists = false;
            foreach ($users as $user) {
                if ($user['username'] === $username) {
                    $userExists = true;
                    break;
                }
            }

            if ($userExists) {
                $error = 'Username sudah digunakan';
            } else {
                $newUser = [
                    'id' => uniqid(),
                    'username' => $username,
                    'password' => password_hash($password, PASSWORD_DEFAULT),
                    'created_at' => time()
                ];

                $users[] = $newUser;
                saveUsers($users);

                $profiles = getProfiles();
                $profiles[$newUser['id']] = [
                    'display_name' => $username,
                    'avatar' => 'default.png',
                    'bio' => ''
                ];
                saveProfiles($profiles);

                $success = 'Pendaftaran berhasil! Silakan login';
            }
        }
    } else {
        foreach ($users as $user) {
            if ($user['username'] === $username && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                setcookie('remember_user', $user['id'], time() + (30 * 24 * 60 * 60), '/');
                header('Location: index.php');
                exit;
            }
        }

        $error = 'Username atau password salah';
    }
}

if (empty($_SESSION['user_id']) && isset($_COOKIE['remember_user'])) {
    $users = getUsers();
    foreach ($users as $user) {
        if ($user['id'] === $_COOKIE['remember_user']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header('Location: index.php');
            exit;
        }
    }
}

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login/Register - Clipshare</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Gaya CSS yang kamu punya tetap sama */
        :root {
            --primary: #FF2D55;
            --secondary: #25F4EE;
            --dark: #121212;
            --light-dark: #1E1E1E;
            --text: #FFFFFF;
            --text-light: rgba(255, 255, 255, 0.7);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background: var(--dark);
            color: var(--text);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background: var(--light-dark);
            padding: 2rem;
            border-radius: 10px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }
        .logo {
            text-align: center;
            margin-bottom: 2rem;
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(to right, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .tabs {
            display: flex;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .tab {
            flex: 1;
            text-align: center;
            padding: 0.5rem;
            cursor: pointer;
            position: relative;
        }
        .tab.active { font-weight: 600; }
        .tab.active::after {
            content: '';
            position: absolute;
            bottom: -1px;
            left: 0;
            right: 0;
            height: 2px;
            background: var(--primary);
        }
        .form-container { display: none; }
        .form-container.active { display: block; }
        .form-group { margin-bottom: 1rem; }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        .form-group input {
            width: 100%;
            padding: 0.8rem;
            border-radius: 5px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            font-size: 1rem;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--primary);
        }
        .btn {
            width: 100%;
            padding: 0.8rem;
            border: none;
            border-radius: 5px;
            background: var(--primary);
            color: white;
            font-weight: 600;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }
        .btn:hover { opacity: 0.9; }
        .error {
            color: #ff4d4d;
            margin-top: 1rem;
            text-align: center;
            font-size: 0.9rem;
        }
        .success {
            color: #4dff4d;
            margin-top: 1rem;
            text-align: center;
            font-size: 0.9rem;
        }
        .nav {
            text-align: center;
            margin-bottom: 1rem;
        }
        .nav a {
            color: var(--text-light);
            text-decoration: none;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <nav class="nav">
            <a href="?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </nav>

        <div class="logo">ClipShare</div>

        <div class="tabs">
            <div class="tab active" data-tab="login">Login</div>
            <div class="tab" data-tab="register">Daftar</div>
        </div>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form id="login-form" class="form-container active" method="post">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label for="login-username">Username</label>
                <input type="text" id="login-username" name="username" required>
            </div>
            <div class="form-group">
                <label for="login-password">Password</label>
                <input type="password" id="login-password" name="password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <form id="register-form" class="form-container" method="post">
            <input type="hidden" name="action" value="register">
            <div class="form-group">
                <label for="register-username">Username</label>
                <input type="text" id="register-username" name="username" required>
            </div>
            <div class="form-group">
                <label for="register-password">Password</label>
                <input type="password" id="register-password" name="password" required>
            </div>
            <button type="submit" class="btn">Daftar</button>
        </form>
    </div>

<script>
    const tabs = document.querySelectorAll('.tab');
    const forms = document.querySelectorAll('.form-container');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Hapus kelas aktif dari semua tab dan form
            tabs.forEach(t => t.classList.remove('active'));
            forms.forEach(f => f.classList.remove('active'));

            // Tambah kelas aktif ke tab yang diklik
            tab.classList.add('active');

            // Tampilkan form sesuai tab yang diklik
            const tabName = tab.getAttribute('data-tab');
            document.getElementById(`${tabName}-form`).classList.add('active');
        });
    });
</script>